use std::fs::{self};
use std::path::Path;
use chrono::{Duration, Utc};
use rand::Rng;
use std::thread;
use std::time::Duration as StdDuration;
use filetime::FileTime;
use std::io;


fn main() -> std::io::Result<()> {
    // Define categories
    let categories = vec!["takeoff", "land", "right", "left", "forward", "backward"];
    for category in categories.iter() {
        let category_path = Path::new("./data").join(category);
        // Unify files from subdirectories into the parent category directory
        unify_files_in_parent_directory(&category_path)?;
        // Rename files sequentially and randomize timestamps
        rename_files(&category_path, category)?;
    }

    // Automate the process, running 3 times every 30 seconds
    run_automatically(categories)?;

    Ok(())
}

// Unify files from subdirectories into the parent category directory
fn unify_files_in_parent_directory(category_path: &Path) -> std::io::Result<()> {
    for entry in fs::read_dir(category_path)? {
        let entry = entry?;
        let path = entry.path();
        if path.is_dir() {
            // Move files from subdirectories to the parent category directory
            for sub_entry in fs::read_dir(&path)? {
                let sub_entry = sub_entry?;
                let sub_file_path = sub_entry.path();
                if sub_file_path.is_file() {
                    let file_name = sub_file_path.file_name().unwrap();
                    let new_path = category_path.join(file_name);

                    // Move the file
                    fs::rename(&sub_file_path, new_path)?;
                }
            }
            // Optionally remove empty subdirectory
            fs::remove_dir(&path)?;
        }
    }
    Ok(())
}

// Function to rename files and change the extension to `.csv`
fn rename_files(category_path: &Path, category_name: &str) -> io::Result<()> {
    let mut counter = 1;
    for entry in fs::read_dir(category_path)? {
        let entry = entry?;
        let path = entry.path();
        if path.is_file() {
            let file_extension = path.extension().unwrap_or_default();
            let mut new_file_name = format!("{}_{}.{}", category_name, counter, file_extension.to_string_lossy());

            // If the file is still .txt, rename to .csv
            if file_extension == "txt" {
                new_file_name = format!("{}_{}.csv", category_name, counter);  // Change extension to .csv
            }

            // Generate the new path and rename the file
            let new_path = category_path.join(new_file_name);
            fs::rename(&path, &new_path)?;

            // Randomize the timestamp for both .csv and .txt files
            randomize_file_timestamp(&new_path)?;

            counter += 1;
        }
    }
    Ok(())
}

// Randomize the timestamp of a file within the last 10 days
fn randomize_file_timestamp(file_path: &Path) -> std::io::Result<()> {
    // Get the current date and time
    let now = Utc::now();
    // Generate a random duration (up to 10 days ago)
    let random_days_ago = rand::thread_rng().gen_range(0..=10);
    let random_duration = Duration::days(random_days_ago);
    let random_time = now - random_duration;

    // Update the file's timestamp
    filetime::set_file_times(
        file_path,
        FileTime::from_unix_time(random_time.timestamp(), 0),
        FileTime::from_unix_time(random_time.timestamp(), 0),
    )?;

    Ok(())
}

// Automate the process to run 3 times, with a 30-second interval between each run
fn run_automatically(categories: Vec<&str>) -> std::io::Result<()> {
    for _ in 0..3 {
        println!("Running file processing...");
        for category in categories.iter() {
            let category_path = Path::new("./data").join(category);
            unify_files_in_parent_directory(&category_path)?;
            rename_files(&category_path, category)?;
        }
        // Wait for 30 seconds before the next run
        thread::sleep(StdDuration::from_secs(30));
    }
    Ok(())
}
